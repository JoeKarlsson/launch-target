(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;

(function(){

///////////////////////////////////////////////////////////////////////
//                                                                   //
// packages/yn5_curious-datetimepicker/packages/yn5_curious-datetime //
//                                                                   //
///////////////////////////////////////////////////////////////////////
                                                                     //
                                                                     // 1
///////////////////////////////////////////////////////////////////////

}).call(this);


/* Exports */
if (typeof Package === 'undefined') Package = {};
Package['yn5:curious-datetimepicker'] = {};

})();

//# sourceMappingURL=yn5_curious-datetimepicker.js.map
