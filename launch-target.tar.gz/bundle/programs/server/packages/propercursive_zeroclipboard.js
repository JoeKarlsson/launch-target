(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;

(function(){

///////////////////////////////////////////////////////////////////////
//                                                                   //
// packages/propercursive_zeroclipboard/packages/propercursive_zeroc //
//                                                                   //
///////////////////////////////////////////////////////////////////////
                                                                     //
                                                                     // 1
///////////////////////////////////////////////////////////////////////

}).call(this);


/* Exports */
if (typeof Package === 'undefined') Package = {};
Package['propercursive:zeroclipboard'] = {};

})();

//# sourceMappingURL=propercursive_zeroclipboard.js.map
