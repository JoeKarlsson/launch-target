(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;

(function(){

///////////////////////////////////////////////////////////////////////
//                                                                   //
// packages/mrt_meteor-flipclockjs/packages/mrt_meteor-flipclockjs.j //
//                                                                   //
///////////////////////////////////////////////////////////////////////
                                                                     //
                                                                     // 1
///////////////////////////////////////////////////////////////////////

}).call(this);


/* Exports */
if (typeof Package === 'undefined') Package = {};
Package['mrt:meteor-flipclockjs'] = {};

})();

//# sourceMappingURL=mrt_meteor-flipclockjs.js.map
