(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;

(function(){

///////////////////////////////////////////////////////////////////////
//                                                                   //
// packages/matthew_foundation5-sass/packages/matthew_foundation5-sa //
//                                                                   //
///////////////////////////////////////////////////////////////////////
                                                                     //
                                                                     // 1
///////////////////////////////////////////////////////////////////////

}).call(this);


/* Exports */
if (typeof Package === 'undefined') Package = {};
Package['matthew:foundation5-sass'] = {};

})();

//# sourceMappingURL=matthew_foundation5-sass.js.map
