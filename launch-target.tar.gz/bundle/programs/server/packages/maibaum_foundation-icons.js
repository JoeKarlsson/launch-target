(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;

(function(){

///////////////////////////////////////////////////////////////////////
//                                                                   //
// packages/maibaum_foundation-icons/packages/maibaum_foundation-ico //
//                                                                   //
///////////////////////////////////////////////////////////////////////
                                                                     //
                                                                     // 1
///////////////////////////////////////////////////////////////////////

}).call(this);


/* Exports */
if (typeof Package === 'undefined') Package = {};
Package['maibaum:foundation-icons'] = {};

})();

//# sourceMappingURL=maibaum_foundation-icons.js.map
